import React from 'react';
import logo from './pic.jpg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          kamalita biswas
        </p>
        <a
          className="App-link"
          href="https://portals.radware.com/"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn radware
        </a>
      </header>
 <div>
  <header >
   <p>New App starts here</p>
  </header>
 </div>
 <table>
  <h1>Select one</h1>
   <ul>
	<li>tea</li>
	<li>coffee</li>
	<li>cold drink</li>
	<li>milk</li>
   </ul>
 </table>
 </div>

  );


}

export default App;