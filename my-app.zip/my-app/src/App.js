import React,{useState, useRef,useEffect} from 'react';
import './index.css';
import TodoList from './TodoList'
import { v4 as uuidv4 } from 'uuid'


function App()
{
   const LOCAL_STORAGE='todoApp.todos'
   const [todos,setTodos] =useState([{id:1,name:'kk',status:'complete'}])
   const initialVal=useRef();

   function toggleTodo(id){
        const newTodos=[...todos]
        const todo=newTodos.find(todo=> todo.id===id)
        todo.status=!todo.status
       setTodos(newTodos)
}


    useEffect(()=>
        {
            const storedTodos=JSON.parse(localStorage.getItem(LOCAL_STORAGE))
            if(storedTodos) setTodos(storedTodos)
        },[]
    )

    useEffect(()=>
   {
       localStorage.setItem(LOCAL_STORAGE,JSON.stringify(todos))
   },[todos]
   )

    function handleAddTodo(e){
        const name = initialVal.current.value
        if(name === '' ) return
        setTodos(prevTodos=>{
           return [...prevTodos,{id:uuidv4(),name:name,status:'complete'}]
        })
        initialVal.current.value=null
    }
    function handleClearTodos(e){
       const name=initialVal.current.value
        const newTodo=todos.filter(todo=>!todo.status)
        if(newTodo) setTodos(newTodo)
    }
    return (
<>

    <TodoList todos={todos} toggleTodo={toggleTodo}  />
    <input ref={initialVal} type= "text" />
    <button onClick={handleClearTodos}>Clear</button>
    <button onClick={handleAddTodo}>Add</button>
    <div>{todos.filter(todo=>!todo.status).length} left Todos</div>

</>
    )
}

export default App;